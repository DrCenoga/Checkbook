
/**
 * Hey, it's a Checkbook.
 *
 * @author (Austin Taylor)
 * @version (1 - June 6, 2017)
 */
public class Checkbook
{
    // instance variables - replace the example below with your own
    private int checkTotal;
    private ArrayList<Check> checks;
    private int a;
    private int currentTotal;
    public int howMany;
    
    /**
     * Create a Checkbook and get their totals.
     */
    public Checkbook(int checkTotal)
    {
        checks = new ArrayList<Check>();
        while(a < howMany){
            a++;
            currentTotal += checks[a].amount;
        }
    }
}
