
/**
 * Ridiculously simple check object
 *
 * @author (Austin Taylor)
 * @version (1 - June 6, 2017)
 */
public class Check
{
    // instance variables - replace the example below with your own
    private String name;
    private String date;
    private int amount;
    private int checkNumber;
    private String reason;
    public int howMany;

    /**
     * Create a new check with several bits of information included.
     */
    public Check(String fullName, String datePaid, int amountPaid, int whichCheck, String whyPay)
    {
        name = fullName;
        date = datePaid;
        amount = amountPaid;
        checkNumber = whichCheck;
        reason = whyPay;
        howMany++;
    }
    
   /**
     * Display all check information
     */
    public void printCheck()
    {
        // Simulate the printing of this check.
        System.out.println("##################");
        System.out.println("Austin Taylor              #" + checkNumber);
        System.out.println("Pay to the order of " + name + ", $" + amount);
        System.out.println("For: " + reason + "      ("+ date +")");
        System.out.println("##################");
        System.out.println();

    }
}
