
/**
 * Write a description of class Check here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Check {
    //  Create a new check with several bits of information included - used in method "write()"
    private String name;
    private String date;
    private int amount;
    private int checkNumber;
    private String reason;
    public int howMany;
    public Check(String fullName, String datePaid, int amountPaid, int whichCheck, String whyPay)
    {
        name = fullName;
        date = datePaid;
        amount = amountPaid;
        checkNumber = whichCheck;
        reason = whyPay;
        howMany++;
    }
   //  Display all check information - needs to be moved to "oneCheck()" method?
    public void printCheck() {
        System.out.println("##################");
        System.out.println("Austin Taylor              #" + checkNumber);
        System.out.println("Pay to the order of " + name + ", $" + amount);
        System.out.println("For: " + reason + "      ("+ date +")");
        System.out.println("##################");
        System.out.println();
    }
}
