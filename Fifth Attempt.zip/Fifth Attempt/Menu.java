import java.util.Scanner;
import java.io.*;
/*
	Helping sources
	http://chronicles.blog.ryanrampersad.com/2011/03/text-based-menu-in-java/
	https://stackoverflow.com/questions/2885173/how-do-i-create-a-file-and-write-to-it-in-java
**/
public class Menu {
	public double balance;  //warned that double not to be used with money - use float?


	private Scanner input = new Scanner(System.in);  // looked up - meaning?
	public void display() {
		System.out.println("1: Get current balance");
		System.out.println("2: List all used checks");  //(FOR loop)
		System.out.println("3: Show a single check");   //(check # - date?)
		System.out.println("4: Write a check");
		System.out.println("5: Deposit money");   // (opposite of a writing check)
		System.out.println("6: Load checks from file");
		System.out.println("7: Save checks");   // to a file - serialize (why does user need to ask? Automatic?)
		System.out.println("0: Quit");
		int selection = input.nextInt();  // why this design?
		input.nextLine();   // used to stop "input skipping?"
	switch (selection) {     // processing the choice from the menu
		case 1: 
			this.balance();
			break;
		case 2: 
			this.allChecks();
			break;
		case 3: 
			this.oneCheck();
			break;
		case 4: 
			this.write();
			break;
		case 5: 
			this.deposit();
			break;
		case 6: 
			this.load();
			break;
		case 7:
			this.saving();
			break;
		case 0:
			this.exit();
			break;
		default:
			System.out.println("Invalid selection.");
			break;
	} 
}
	private void balance() {
		System.out.println("Balance.");
				// need a variable for balance (see above) - will be used in "write()" and "deposit()"
	}
	private void allChecks() {
		System.out.println("All of your checks.");
	}
	private void oneCheck() {
		System.out.println("Just one check.");
	}
	private void write() {
		System.out.println("Write a check.");
	}
	private void deposit() {
		System.out.println("Deposit money.");
	}
	private void load() {
		System.out.println("Load another checkbook.");
	}
	private void saving() {
		System.out.println("Save this checkbook.");
		try{
    		PrintWriter writer = new PrintWriter("checkbook-01.txt", "UTF-8");  // will overwrite existing file, utf?
   			writer.println("The first line");    // logically this is check 1 of 10
    		writer.println("The second line");   // next check in line
   			 writer.close();                     // how to tell when done?
		} catch (IOException e) {
			System.out.println("Error. Checkbook not saved.");
		}
	}
	private void exit() {
		System.out.println("Closing checkbook.");
		System.exit(1);  // closes entire program?
	}
}






