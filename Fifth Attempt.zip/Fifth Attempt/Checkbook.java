
/**
 * Write a description of class Checkbook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Checkbook
{
  	public static void main(String[] args) {
		Menu menu = new Menu();
		while (true)
			menu.display();
	}
}
